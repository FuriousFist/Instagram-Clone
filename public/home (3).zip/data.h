/* data.h
 *
 * Created by Armaan Singh Sidhu and Natty Ayano 
 * (ArmaanSingh.Sidhu@student.unimelb.edu.au & nayano@student.unimelb.edu.au) 
 * 21/08/2025
 *
 * Header file for handling of Victorian address data.
 * Defines structures and functions for reading, storing, and processing
 * address records in CSV files with 35 fields.
 */


#ifndef _DATA_H_
#define _DATA_H_

#include <stdio.h>

#define FIELD_COUNT 35

#define MAX_LINE_LENGTH 512
#define X_POS 33
#define Y_POS 34

typedef struct list list_t;

typedef struct { // contains all the fields from each row in the csv 
    char *fields[FIELD_COUNT];    
} address_t;

/*
 * Reads a single line from the input CSV and returns a pointer to an address_t struct
*/
address_t *data_read(FILE *input_file);

/*
 * Gets the key of the address
*/
const char *address_get_key(const void *address);

/*
 * Prints the record to the output file
*/
void address_print_file(FILE *output_file, void *address);

/*
 * Frees an address record
*/
void address_free(void *address);

/*
 * Parse CSV line into field array (if you want this to be public)
*/
int parse_line(char *line, char *fields[], int max_fields);

/*
 * Build an address dictionary
 * 
*/
void buildDictionary(FILE *f, list_t *dictionary);

/*
 * Prints to output file the key and the matching results. 
*/
void output_results(list_t *dict, FILE *output_file);

/*
 * Removes the newline character from the strings nom nom 
 */
void chomp(char *s);
#endif

