/* bit.h
 *
 * Created by Armaan Singh Sidhu, Natty Ayano and The University of Melbourne
 * (ArmaanSingh.Sidhu@student.unimelb.edu.au & nayano@student.unimelb.edu.au) 
 * 21/08/2025
 *
 * Header file for bit-level string comparison operations.
 * Provides functions to extract individual bits from strings and count
 * bit-level comparisons until the first mismatch for performance analysis
 */

/* Number of bits in a single character. */
#define BITS_PER_BYTE 8

/*
 * Extracts a single bit from a string at the specified bit index
*/
int getBit(const char *s, unsigned int bitIndex);

/*
 * Compares two strings bit by bit and counts comparisons until first mismatch
*/
int count_bit_comparisons(const char *key1, const char *key2);
